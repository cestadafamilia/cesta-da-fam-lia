import { getStore } from "@netlify/blobs";
import { createHash, randomBytes } from "node:crypto";

// Senha inicial: 102030121 (pode trocar dentro do painel)
const DEFAULT_HASH = "bd353086b7746d896034644c347b23a59b672119a2f33049096e4f1768fb5ef4";
const CHUNK = 3 * 1024 * 1024;
const MAX_BODY = 5.5 * 1024 * 1024;
const sha = (t) => createHash("sha256").update(String(t)).digest("hex");
const wait = (ms) => new Promise((r) => setTimeout(r, ms));
const json = (o, status = 200) =>
  new Response(JSON.stringify(o), {
    status,
    headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" },
  });

export default async (req) => {
  const url = new URL(req.url);
  const path = url.pathname.replace(/^\/api\/?/, "");
  const store = getStore({ name: "cesta-familia", consistency: "strong" });
  const getState = async () => (await store.get("state", { type: "json" })) || null;
  const authed = async () => {
    const st = await getState();
    return sha(req.headers.get("x-senha") || "") === ((st && st.senha) || DEFAULT_HASH);
  };
  const deny = async () => {
    await wait(800);
    return json({ erro: "senha" }, 401);
  };

  try {
    if (req.method === "GET" && path === "state") {
      const st = await getState();
      if (!st) return json({});
      const { senha, ...pub } = st;
      return json(pub);
    }

    if (req.method === "GET" && path.startsWith("img/")) {
      const id = path.slice(4);
      if (!/^u[a-z0-9]{6,40}$/.test(id)) return new Response("not found", { status: 404 });
      const r = await store.getWithMetadata(id, { type: "arrayBuffer" });
      if (!r) return new Response("not found", { status: 404 });
      return new Response(r.data, {
        headers: {
          "content-type": (r.metadata && r.metadata.type) || "image/jpeg",
          "cache-control": "public, max-age=31536000, immutable",
        },
      });
    }

    if (req.method === "GET" && path.startsWith("video/")) {
      const id = path.slice(6);
      const st = await getState();
      const v = st && st.video;
      if (!v || v.id !== id || !/^v[a-z0-9]{6,40}$/.test(id)) return new Response("not found", { status: 404 });
      const total = Number(v.total);
      const m = /^bytes=(\d*)-(\d*)$/.exec(req.headers.get("range") || "bytes=0-");
      if (!m) return new Response("range", { status: 416 });
      const start = m[1] === "" ? Math.max(0, total - Number(m[2])) : Number(m[1]);
      let end = m[1] === "" || m[2] === "" ? total - 1 : Number(m[2]);
      if (start >= total) return new Response("range", { status: 416, headers: { "content-range": "bytes */" + total } });
      const idx = Math.floor(start / CHUNK);
      end = Math.min(end, total - 1, (idx + 1) * CHUNK - 1);
      const data = await store.get("v-" + id + "-" + idx, { type: "arrayBuffer" });
      if (!data) return new Response("not found", { status: 404 });
      const part = data.slice(start - idx * CHUNK, end - idx * CHUNK + 1);
      return new Response(part, {
        status: 206,
        headers: {
          "content-type": v.type || "video/mp4",
          "content-range": "bytes " + start + "-" + end + "/" + total,
          "content-length": String(part.byteLength),
          "accept-ranges": "bytes",
          "cache-control": "public, max-age=3600",
        },
      });
    }

    if (req.method === "POST" && path === "login") {
      return (await authed()) ? json({ ok: true }) : deny();
    }

    if (req.method === "POST" && path === "upload") {
      if (!(await authed())) return deny();
      const buf = await req.arrayBuffer();
      if (buf.byteLength > MAX_BODY) return json({ erro: "grande" }, 413);
      const vid = url.searchParams.get("vid");
      if (vid) {
        const n = Number(url.searchParams.get("n"));
        if (!/^v[a-z0-9]{6,40}$/.test(vid) || !Number.isInteger(n) || n < 0 || n > 20) return json({ erro: "param" }, 400);
        await store.set("v-" + vid + "-" + n, buf);
        return json({ ok: true });
      }
      const type = req.headers.get("content-type") || "";
      if (!type.startsWith("image/")) return json({ erro: "tipo" }, 400);
      const id = "u" + randomBytes(8).toString("hex");
      await store.set(id, buf, { metadata: { type } });
      return json({ id });
    }

    if (req.method === "POST" && path === "state") {
      if (!(await authed())) return deny();
      const b = await req.json();
      const idOk = /^[0-9a-zA-Z]{6,40}$/;
      if (!Array.isArray(b.encartes) || b.encartes.length > 60) return json({ erro: "dados" }, 400);
      const encartes = b.encartes.map((e) => ({ id: String(e.id), titulo: String(e.titulo || "").slice(0, 120) }));
      if (encartes.some((e) => !idOk.test(e.id))) return json({ erro: "dados" }, 400);
      let video = null;
      if (b.video && b.video.id) {
        if (!/^v[a-z0-9]{6,40}$/.test(b.video.id)) return json({ erro: "dados" }, 400);
        video = {
          id: b.video.id,
          total: Number(b.video.total) || 0,
          chunks: Number(b.video.chunks) || 0,
          type: String(b.video.type || "video/mp4").slice(0, 40),
        };
      }
      const old = await getState();
      let senha = (old && old.senha) || DEFAULT_HASH;
      if (typeof b.novaSenha === "string" && b.novaSenha.length >= 4 && b.novaSenha.length <= 64) senha = sha(b.novaSenha);
      await store.setJSON("state", {
        encartes,
        aviso: String(b.aviso || "").slice(0, 300),
        whatsapp: String(b.whatsapp || "").replace(/\D/g, "").slice(0, 15),
        video,
        senha,
      });
      return json({ ok: true });
    }

    return new Response("not found", { status: 404 });
  } catch (e) {
    return json({ erro: "servidor", detalhe: String((e && e.message) || e) }, 500);
  }
};

export const config = { path: "/api/*" };
