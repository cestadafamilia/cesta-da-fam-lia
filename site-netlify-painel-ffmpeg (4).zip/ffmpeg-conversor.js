/* ============================================================
   Conversor de vídeo no navegador (FFmpeg.wasm)
   ------------------------------------------------------------
   Arquivo ADICIONAL: não altera nenhuma função do site/painel.
   Ele "escuta" o campo #adVidFile (Enviar vídeo MP4 do celular),
   converte o vídeo escolhido para MP4 H.264/AAC mais leve e só
   então entrega o arquivo convertido ao fluxo de envio que já
   existia. Se qualquer coisa falhar (sem internet para baixar o
   conversor, pouca memória etc.), o vídeo ORIGINAL segue pelo
   fluxo normal, exatamente como era antes.
   ============================================================ */
(function () {
  "use strict";

  var FFMPEG_VER = "0.12.10";   // @ffmpeg/ffmpeg
  var CORE_VER = "0.12.6";      // @ffmpeg/core (versão de 1 thread: não exige cabeçalhos COOP/COEP)
  var CDNS = ["https://cdn.jsdelivr.net/npm", "https://unpkg.com"];
  var MAX_BYTES = 200 * 1024 * 1024; // acima disso nem tenta converter no aparelho (memória do celular)

  var ffPromise = null, converting = false, passthrough = false, stage = "";
  console.info("[ffmpeg] conversor de vídeo ativo");

  function $(s) { return document.querySelector(s); }

  function say(t, err) {
    var st = $("#adStatus");
    if (!st) return;
    st.textContent = t;
    st.className = "ad-status" + (err ? " err" : "");
  }

  /* ---------- carregamento da biblioteca (só quando for preciso) ---------- */
  function loadScript(src) {
    return new Promise(function (res, rej) {
      var s = document.createElement("script");
      s.src = src; s.onload = res;
      s.onerror = function () { rej(new Error("script " + src)); };
      document.head.appendChild(s);
    });
  }

  function blobURL(url, type) {
    return fetch(url).then(function (r) {
      if (!r.ok) throw new Error("download " + r.status);
      return r.blob();
    }).then(function (b) { return URL.createObjectURL(new Blob([b], { type: type })); });
  }

  function withTimeout(promise, ms, what) {
    return new Promise(function (res, rej) {
      var t = setTimeout(function () { rej(new Error("tempo esgotado ao " + what)); }, ms);
      promise.then(function (v) { clearTimeout(t); res(v); }, function (e) { clearTimeout(t); rej(e); });
    });
  }

  async function loadFrom(base) {
    var ffBase = base + "/@ffmpeg/ffmpeg@" + FFMPEG_VER + "/dist/umd";
    var coreBase = base + "/@ffmpeg/core@" + CORE_VER + "/dist/";
    stage = "baixar o conversor (internet/VPN?)";
    if (!window.FFmpegWASM) await loadScript(ffBase + "/ffmpeg.js");
    var wasm = await blobURL(coreBase + "umd/ffmpeg-core.wasm", "application/wasm");
    var worker = await blobURL(ffBase + "/814.ffmpeg.js", "text/javascript");
    var last;
    // Com classWorkerURL o FFmpeg abre o worker como "módulo" => precisa do núcleo ESM.
    // O UMD fica como reserva (caso o worker seja clássico).
    var kinds = ["esm", "umd"];
    for (var i = 0; i < kinds.length; i++) {
      var ff = null;
      try {
        stage = "baixar o conversor (internet/VPN?)";
        var core = await blobURL(coreBase + kinds[i] + "/ffmpeg-core.js", "text/javascript");
        stage = "iniciar o conversor";
        ff = new window.FFmpegWASM.FFmpeg();
        await withTimeout(ff.load({ coreURL: core, wasmURL: wasm, classWorkerURL: worker }), 120000, "iniciar o conversor");
        console.info("[ffmpeg] núcleo carregado:", kinds[i]);
        return ff;
      } catch (e) {
        last = e;
        console.warn("[ffmpeg] núcleo " + kinds[i] + " falhou:", e);
        try { if (ff) ff.terminate(); } catch (e2) {}
      }
    }
    throw last;
  }

  function getFF() {
    if (!ffPromise) {
      ffPromise = (async function () {
        var last;
        for (var i = 0; i < CDNS.length; i++) {
          try { return await loadFrom(CDNS[i]); } catch (e) { last = e; }
        }
        throw last || new Error("não foi possível carregar o FFmpeg");
      })();
      ffPromise.catch(function () { ffPromise = null; }); // permite tentar de novo depois
    }
    return ffPromise;
  }

  function resetFF() {
    var p = ffPromise; ffPromise = null;
    if (p) p.then(function (ff) { try { ff.terminate(); } catch (e) {} }, function () {});
  }

  /* ---------- conversão ---------- */
  async function convert(file, buf, onProgress) {
    var ff = await getFF();
    stage = "enviar o vídeo ao conversor";
    var id = Date.now().toString(36);
    var ext = (/\.([a-z0-9]{2,4})$/i.exec(file.name) || [0, "mp4"])[1].toLowerCase();
    var inName = "in-" + id + "." + ext, outName = "out-" + id + ".mp4";
    var handler = function (e) {
      var p = e && typeof e.progress === "number" ? e.progress : 0;
      onProgress(Math.max(0, Math.min(99, Math.round(p * 100))));
    };
    ff.on("progress", handler);
    try {
      await ff.writeFile(inName, new Uint8Array(buf));
      stage = "converter o vídeo";
      var code = await ff.exec([
        "-i", inName,
        "-map", "0:v:0", "-map", "0:a:0?",
        // lado maior limitado (720 em pé / 1280 deitado), medidas pares
        "-vf", "scale=w='trunc(if(gt(iw,ih),min(1280,iw),min(720,iw))/2)*2':h=-2",
        "-c:v", "libx264", "-preset", "superfast", "-crf", "28",
        "-pix_fmt", "yuv420p", "-profile:v", "main",
        "-c:a", "aac", "-b:a", "96k", "-ac", "2",
        "-movflags", "+faststart",   // permite começar a tocar sem baixar tudo
        outName
      ]);
      if (code !== 0) throw new Error("ffmpeg código " + code);
      var data = await ff.readFile(outName);
      if (!data || !data.length) throw new Error("saída vazia");
      var base = file.name.replace(/\.[^.]+$/, "") || "video";
      return new File([data], base + ".mp4", { type: "video/mp4" });
    } catch (e) {
      resetFF(); // após erro (ex.: falta de memória) recomeça limpo na próxima vez
      throw e;
    } finally {
      try { ff.off("progress", handler); } catch (e) {}
      try { await ff.deleteFile(inName); } catch (e) {}
      try { await ff.deleteFile(outName); } catch (e) {}
    }
  }

  function canPlay(f) {
    return new Promise(function (res) {
      var v = document.createElement("video"), u = URL.createObjectURL(f);
      var done = function (ok) { clearTimeout(t); URL.revokeObjectURL(u); res(ok); };
      var t = setTimeout(function () { done(true); }, 8000);
      v.preload = "metadata"; v.muted = true;
      v.onloadedmetadata = function () { done(v.videoWidth > 0); };
      v.onerror = function () { done(false); };
      v.src = u;
    });
  }

  /* ---------- entrega ao fluxo original ---------- */
  function forward(input, file) {
    if (input.files && input.files[0] !== file) {
      try {
        var dt = new DataTransfer();
        dt.items.add(file);
        input.files = dt.files;
      } catch (e) { /* aparelho não permite trocar o arquivo: segue com o original */ }
    }
    passthrough = true;
    try { input.dispatchEvent(new Event("change", { bubbles: true })); }
    finally { passthrough = false; }
  }

  function mb(n) { return (n / 1048576).toFixed(1).replace(".", ",") + " MB"; }

  async function handle(input, file) {
    var looksVideo = /^video\//.test(file.type) || /\.(mp4|mov|m4v|3gp|webm|mkv)$/i.test(file.name);
    if (!looksVideo || file.size > MAX_BYTES) { forward(input, file); return; }

    // O Chrome do Android invalida o arquivo escolhido se demorarmos a lê-lo:
    // a leitura começa AGORA, antes de qualquer espera (download do conversor etc.).
    var readP = file.arrayBuffer();
    readP.catch(function () {});

    converting = true;
    var ids = ["#adVidBtn", "#adSave", "#adAdd"], prev = {}, lock = null;
    ids.forEach(function (s) { var b = $(s); if (b) { prev[s] = b.disabled; b.disabled = true; } });
    try { if (navigator.wakeLock) lock = await navigator.wakeLock.request("screen"); } catch (e) {}

    var chosen = file, failed = "";
    try {
      say("Lendo o vídeo…");
      stage = "ler o vídeo";
      var buf = await readP;
      // cópia em memória: o "original" deixa de depender do arquivo do celular
      file = new File([buf], file.name, { type: file.type || "video/mp4" });
      say("Preparando o conversor de vídeo… (na primeira vez baixa uns 30 MB)");
      var out = await convert(file, buf, function (p) {
        say("Convertendo vídeo… " + p + "% (não feche a tela)");
      });
      // se a conversão não reduziu e o original abre normalmente, mantém o original
      if (out.size >= file.size && (await canPlay(file))) {
        chosen = file; // cópia em memória do original
        console.info("[ffmpeg] original mantido:", mb(file.size), "→", mb(out.size));
      } else {
        chosen = out;
        console.info("[ffmpeg] convertido:", mb(file.size), "→", mb(out.size));
      }
    } catch (e) {
      console.warn("[ffmpeg] falha em '" + stage + "':", e);
      failed = "Falha ao " + stage + ": " + String((e && e.message) || e).slice(0, 120) + ".";
      failed += /baixar/.test(stage) ? " Confira a internet (desligue a VPN) e tente de novo."
        : /ler/.test(stage) ? " Escolha o vídeo da Galeria ou da pasta Downloads do celular (não direto da nuvem) e tente de novo."
        : " Me envie um print desta mensagem.";
    }

    converting = false;
    ids.forEach(function (s) { var b = $(s); if (b) b.disabled = prev[s]; });
    try { if (lock) lock.release(); } catch (e) {}

    // se o painel foi fechado durante a conversão, a senha já foi descartada: não envia
    var dlg = $("#admin");
    if (dlg && !dlg.open) { input.value = ""; return; }
    if (failed) {
      // original abre normalmente? então segue sem converter; senão mostra o motivo real
      if (!(await canPlay(file))) {
        say("Não consegui converter este vídeo. " + failed, true);
        input.value = "";
        return;
      }
    }
    forward(input, chosen);
  }

  /* captura o "change" ANTES do código original e o repassa depois da conversão */
  document.addEventListener("change", function (ev) {
    var el = ev.target;
    if (!el || el.id !== "adVidFile" || passthrough) return;
    var f = el.files && el.files[0];
    if (!f) return;
    ev.stopImmediatePropagation();
    if (converting) { el.value = ""; return; }
    handle(el, f);
  }, true);
})();
